@echo off
setlocal

:: Check if already running as Administrator
net session >nul 2>&1
if %errorLevel% == 0 (
    goto :run
) else (
    echo A permission box will pop up in a moment.
    echo Please click "Yes" on it.
    timeout /t 2 >nul
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:run
title Computer Cleanup - Please Wait
color 1F
cls
echo ============================================================
echo    COMPUTER CLEANUP IS RUNNING
echo    Please do not close this window.
echo ============================================================
echo.
echo You will see text scrolling by below. This is normal.
echo It may take a few minutes.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cleanup.ps1"
echo.
echo ============================================================
echo    ALL DONE!
echo    You can close this window now.
echo ============================================================
echo.
pause
