$ErrorActionPreference = "SilentlyContinue"
$DownloadDir = "$env:USERPROFILE\Desktop\CleanupTools"
New-Item -ItemType Directory -Force -Path $DownloadDir | Out-Null

# ============================================================
#  STEP 0: BACKUP BOOKMARKS + LIST EXTENSIONS (before Chrome is wiped)
# ============================================================

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  STEP 1 of 6: Saving bookmarks + extensions list..." -ForegroundColor Cyan
Write-Host "============================================`n"

$chromeProfile = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default"
$bookmarksSrc  = "$chromeProfile\Bookmarks"
$extensionsDir = "$chromeProfile\Extensions"

if (Test-Path $bookmarksSrc) {
    Write-Host "Saving bookmarks..." -ForegroundColor Yellow
    $json = Get-Content $bookmarksSrc -Raw | ConvertFrom-Json
    Add-Type -AssemblyName System.Web

    function Convert-BookmarkNode {
        param($node, $indent = 0)
        $pad = "    " * $indent
        $lines = @()
        if ($node.type -eq "url") {
            $name = [System.Web.HttpUtility]::HtmlEncode($node.name)
            $url  = [System.Web.HttpUtility]::HtmlEncode($node.url)
            $lines += "$pad<DT><A HREF=`"$url`">$name</A>"
        } elseif ($node.type -eq "folder") {
            $name = [System.Web.HttpUtility]::HtmlEncode($node.name)
            $lines += "$pad<DT><H3>$name</H3>"
            $lines += "$pad<DL><p>"
            foreach ($child in $node.children) { $lines += Convert-BookmarkNode -node $child -indent ($indent + 1) }
            $lines += "$pad</DL><p>"
        }
        return $lines
    }

    $html = @("<!DOCTYPE NETSCAPE-Bookmark-file-1>", "<TITLE>Bookmarks</TITLE>", "<H1>Bookmarks</H1>", "<DL><p>")
    foreach ($root in @("bookmark_bar", "other", "synced")) {
        $rootNode = $json.roots.$root
        if ($rootNode -and $rootNode.children.Count -gt 0) { $html += Convert-BookmarkNode -node $rootNode -indent 1 }
    }
    $html += "</DL><p>"
    $html | Out-File -FilePath "$DownloadDir\bookmarks_backup.html" -Encoding UTF8
    Write-Host "  Done - saved to Desktop\CleanupTools\bookmarks_backup.html" -ForegroundColor Green
} else {
    Write-Host "  No bookmarks file found - skipping." -ForegroundColor DarkGray
}

if (Test-Path $extensionsDir) {
    Write-Host "Saving list of installed extensions..." -ForegroundColor Yellow
    $builtins = @("nmmhkkegccagdldgiimedpiccmgmieda","pkedcjkdefgpdelpbcmbmeomcjbeemfm","ghbmnnjooekpmoecnnnilnnbdlolhkhi","aapocclcgogkmnckokdopfmhonfmgoek","aohghmighlieiainnegkcijnfilokake","felcaaldnbdncclmgdcncolpebgiejap","apdfllckaahabafndbhieahigkjlhalf","blpcfgokakmgnkcojhhkbfbldkacnbeo","coobgpohoikkiipiblmjeljniedjpjpf")
    $knownSafe = @("cjpalhdlnbpafiamejdnhcphjbkeiagm","ddkjiahejlhfcafbddmgiahcphecmpfh","cfhdojbkjhnklbpkdaibdccddilifddb","gighmmpiobklfepjocnamgkkbiglidom","eimadpbcbfnmbkopoojfekhnkhdbieeh","hdokiejnpimakedhajhdlcegeplioahd","aeblfdkhhhdcdjpifhhbdiojplfjncoa","nngceckbapebfimnlniiiahkandclblb","oocalimimngaihdkbihfgmpkcpnmlaoa","bmnlcjabgnpnenekpadlanbbkooimhnj","mnjggcdmjocbbbhaepdhchncahnbgone","lkbebcjgcmobggallkojdlmcogkbcena")

    $r = @("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Extensions Report</title><style>
        body{font-family:Segoe UI,sans-serif;background:#111827;color:#e2e8f0;padding:32px;}
        h1{font-size:20px;} table{width:100%;border-collapse:collapse;font-size:13px;margin-top:16px;}
        th{text-align:left;padding:10px 14px;background:#1e293b;color:#94a3b8;}
        td{padding:9px 14px;border-bottom:1px solid #1e293b;}
        .tag{display:inline-block;font-size:10px;font-weight:700;padding:2px 8px;border-radius:3px;}
        .safe{background:rgba(16,185,129,.15);color:#10b981;} .review{background:rgba(245,158,11,.12);color:#f59e0b;}
        .builtin{background:rgba(100,116,139,.12);color:#64748b;} a{color:#3b82f6;}
        </style></head><body><h1>Chrome Extensions - Before Cleanup</h1>")
    $r += "<table><tr><th>Name</th><th>Version</th><th>Web Store Link</th><th>Verdict</th></tr>"

    Get-ChildItem $extensionsDir -Directory | ForEach-Object {
        $extId = $_.Name
        if ($extId.Length -ne 32) { return }
        $versionDir = Get-ChildItem $_.FullName -Directory | Sort-Object Name -Descending | Select-Object -First 1
        if (-not $versionDir) { return }
        $manifestPath = Join-Path $versionDir.FullName "manifest.json"
        if (-not (Test-Path $manifestPath)) { return }
        try { $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json } catch { return }
        $extName = $manifest.name; $extVersion = $manifest.version
        if ($extName -like "__MSG_*") {
            $msgKey = $extName -replace "^__MSG_(.+)__$", '$1'
            foreach ($locale in @("en_US","en")) {
                $lp = Join-Path $versionDir.FullName "_locales\$locale\messages.json"
                if (Test-Path $lp) { try { $msgs = Get-Content $lp -Raw | ConvertFrom-Json; $resolved = $msgs.$msgKey.message; if ($resolved) { $extName = $resolved; break } } catch {} }
            }
        }
        $storeUrl = "https://chromewebstore.google.com/detail/$extId"
        $safeName = [System.Web.HttpUtility]::HtmlEncode($extName)
        $tag = if ($builtins -contains $extId) { "<span class='tag builtin'>Built-in</span>" }
               elseif ($knownSafe -contains $extId) { "<span class='tag safe'>Known safe</span>" }
               else { "<span class='tag review'>Check before reinstalling</span>" }
        $r += "<tr><td>$safeName</td><td>$([System.Web.HttpUtility]::HtmlEncode($extVersion))</td><td><a href='$storeUrl'>$extId</a></td><td>$tag</td></tr>"
    }
    $r += "</table></body></html>"
    $r | Out-File -FilePath "$DownloadDir\extensions_report.html" -Encoding UTF8
    Write-Host "  Done - saved to Desktop\CleanupTools\extensions_report.html" -ForegroundColor Green
} else {
    Write-Host "  No extensions found - skipping." -ForegroundColor DarkGray
}

# ============================================================
#  STEP 2: DOWNLOAD CLEANUP TOOLS
# ============================================================

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  STEP 2 of 6: Downloading extra cleanup tools..." -ForegroundColor Cyan
Write-Host "============================================`n"

try {
    Invoke-WebRequest -Uri "https://downloads.malwarebytes.com/file/adwcleaner" -OutFile "$DownloadDir\AdwCleaner.exe" -UseBasicParsing
    Write-Host "  AdwCleaner downloaded." -ForegroundColor Green
} catch { Write-Host "  Could not download AdwCleaner - skip for now." -ForegroundColor Red }

try {
    Invoke-WebRequest -Uri "https://dl.surfright.nl/HitmanPro_x64.exe" -OutFile "$DownloadDir\HitmanPro.exe" -UseBasicParsing
    Write-Host "  HitmanPro downloaded." -ForegroundColor Green
} catch { Write-Host "  Could not download HitmanPro - skip for now." -ForegroundColor Red }

# ============================================================
#  STEP 3: REMOVE CHROME + INFECTED DATA
# ============================================================

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  STEP 3 of 6: Removing Chrome and infected files..." -ForegroundColor Cyan
Write-Host "============================================`n"

Stop-Process -Name "chrome" -Force
Start-Sleep -Seconds 2

$chromeUninstall = (Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*" | Where-Object { $_.DisplayName -like "*Google Chrome*" }).UninstallString
if ($chromeUninstall) {
    $chromeUninstall = $chromeUninstall -replace '"',''
    Start-Process -FilePath $chromeUninstall -ArgumentList "--uninstall --force-uninstall" -Wait
    Write-Host "  Chrome removed." -ForegroundColor Green
} else {
    Write-Host "  Chrome was not found (may already be removed)." -ForegroundColor DarkGray
}

foreach ($path in @("$env:LOCALAPPDATA\Google\Chrome", "$env:APPDATA\Google\Chrome")) {
    if (Test-Path $path) { Remove-Item -Recurse -Force $path; Write-Host "  Cleaned up leftover Chrome files." -ForegroundColor Green }
}

# ============================================================
#  STEP 4: SET SAFER DNS
# ============================================================

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  STEP 4 of 6: Turning on extra network protection..." -ForegroundColor Cyan
Write-Host "============================================`n"

Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | ForEach-Object {
    Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ("9.9.9.9","149.112.112.112")
    Write-Host "  Protection enabled." -ForegroundColor Green
}
ipconfig /flushdns | Out-Null

# ============================================================
#  STEP 5: REMOVE KNOWN BAD STARTUP PROGRAMS
# ============================================================

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  STEP 5 of 6: Removing programs that start automatically..." -ForegroundColor Cyan
Write-Host "============================================`n"

$badKeys = @("OneLaunch","Adware","Elex","Wajam","SearchProtect","SupTab")
$runKeys = @(
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"
)
foreach ($key in $runKeys) {
    $props = Get-ItemProperty $key -ErrorAction SilentlyContinue
    if ($props) {
        foreach ($prop in ($props.PSObject.Properties | Where-Object { $_.Name -notlike "PS*" })) {
            foreach ($bad in $badKeys) {
                if ($prop.Name -like "*$bad*" -or $prop.Value -like "*$bad*") {
                    Write-Host "  Removed: $($prop.Name)" -ForegroundColor Green
                    Remove-ItemProperty -Path $key -Name $prop.Name -Force
                }
            }
        }
    }
}

# ============================================================
#  STEP 6: EMPTY RECYCLE BIN
# ============================================================

Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  STEP 6 of 6: Emptying the Recycle Bin..." -ForegroundColor Cyan
Write-Host "============================================`n"
Clear-RecycleBin -Force
Write-Host "  Done." -ForegroundColor Green

Write-Host "`n============================================" -ForegroundColor Green
Write-Host "  AUTOMATIC CLEANUP FINISHED" -ForegroundColor Green
Write-Host "============================================"
Write-Host ""
Write-Host "A folder called CleanupTools was created on the Desktop." -ForegroundColor White
Write-Host "It has your bookmarks, an extensions list, and 2 more tools to run." -ForegroundColor White
Write-Host "See the guide for what to do next." -ForegroundColor White
Write-Host ""
